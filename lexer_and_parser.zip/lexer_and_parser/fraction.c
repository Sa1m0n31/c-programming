struct fraction {
	int licznik;
	int mianownik;
};
