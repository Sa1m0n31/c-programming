%{

 #include <stdio.h>
 #include <stdlib.h>
 #include "fraction.c"
 #include "y.tab.h"

%}

digit [0-9]
digits {digit}+
plus "+"
minus "-"
mult "*"
div "/"
op_bracket "("
cl_bracket ")"
kreska "|"

%%

{digits} { yylval.intval = strtol(yytext, NULL, 10); return CALKOWITA; }

{kreska} { return KRESKA; }

{plus} { return PLUS; }

{minus} { return MINUS; }

{mult} { return MNOZ; }

{div} { return DZIEL; }

{op_bracket} { return OTW; }

{cl_bracket} { return ZAM; }

\n { return yytext[0]; }

. { /* pomijaj niedopasowane znaki */ }

%%
