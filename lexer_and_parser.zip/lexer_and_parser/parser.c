%{

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "fraction.c"

int yylex();
int yyerror();
struct fraction add();
struct fraction subtract();
struct fraction divide();
struct fraction multiply();
void printResult();
struct fraction fractionReduction();
int findGCD();
int counter = 0;
%}


%union {
  int intval;
  struct fraction fracval;
}

%token<intval> CALKOWITA
%token KRESKA
%token PLUS 
%token MINUS 
%token MNOZ 
%token DZIEL 
%token OTW 
%token ZAM

%type<fracval> wyrazenie
%type<fracval> skladnik
%type<fracval> czynnik
%type<intval> liczba

%%

calosc :
| calosc wiersz
;

wiersz : '\n'
| wyrazenie '\n' { printResult(fractionReduction($1)); counter++; }

wyrazenie : wyrazenie PLUS skladnik { $$ = add($1, $3); }
 | wyrazenie MINUS skladnik { $$ = subtract($1, $3); }
 | skladnik { $$ = $1; }
;

skladnik : skladnik MNOZ czynnik { $$ = multiply($1, $3);  }
| skladnik DZIEL czynnik { $$ = divide($1, $3); }
| czynnik
;

czynnik : liczba KRESKA liczba { 
		  struct fraction newFraction;
		  newFraction.licznik = $1;
		  newFraction.mianownik = $3;
		  $$ = newFraction; }
 | OTW wyrazenie ZAM { $$ = $2; }

liczba : CALKOWITA { $$ = $1; }
 | MINUS CALKOWITA { $$ = -$2; }

%%

int main() {
	yyparse();
	printf("Niepoprawne wyrazenie. Przeczytano %d poprawnych wyrazen\n\n", counter);
	return 0;
}

void printResult(struct fraction frac) {
	printf("%d|%d\n", frac.licznik, frac.mianownik);
}

int findGCD(int a, int b) {
	int x, y;
	if(a >= b) {
		x = a;
		y = b;
	}
	else {
		x = b;
		y = a;
	}

	if(y == 0) return x;
	else return findGCD(y, x%y);
}

struct fraction fractionReduction(struct fraction frac) {
	int gcd = findGCD(abs(frac.licznik), abs(frac.mianownik));

	struct fraction resultFrac;
	resultFrac.licznik = frac.licznik / gcd;
	resultFrac.mianownik = frac.mianownik / gcd;
	return resultFrac;
}

struct fraction add(struct fraction frac1, struct fraction frac2) {
	int licznik = frac1.licznik * frac2.mianownik + frac2.licznik * frac1.mianownik;
	int mianownik = frac1.mianownik * frac2.mianownik;
	struct fraction resultFrac;
	resultFrac.licznik = licznik;
	resultFrac.mianownik = mianownik;
	return resultFrac;

}

struct fraction subtract(struct fraction frac1, struct fraction frac2) {
	int licznik = frac1.licznik * frac2.mianownik - frac2.licznik * frac1.mianownik;
	int mianownik = frac1.mianownik * frac2.mianownik;
	struct fraction resultFrac;
	resultFrac.licznik = licznik;
	resultFrac.mianownik = mianownik;
	return resultFrac;
	
}

struct fraction divide(struct fraction frac1, struct fraction frac2) {
	int licznik = frac1.licznik * frac2.mianownik;
	int mianownik = frac1.mianownik * frac2.licznik;
	struct fraction resultFrac;
	resultFrac.licznik = licznik;
	resultFrac.mianownik = mianownik;
	return resultFrac;
}

struct fraction multiply(struct fraction frac1, struct fraction frac2) {
	int licznik = frac1.licznik * frac2.licznik;
	int mianownik = frac1.mianownik * frac2.mianownik;
	struct fraction resultFrac;
	resultFrac.licznik = licznik;
	resultFrac.mianownik = mianownik;
	return resultFrac;
}

int yyerror(char *s) {
printf("Blad: %s\n", s);
}
